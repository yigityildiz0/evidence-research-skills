# Module: data-dashboard

> Part of the `data-analyst` skill. Paths below are relative to this module folder (`modules/data-dashboard/`).
> Original trigger scope: Plan, build, review, or improve a decision-focused dashboard with metric definitions, owners, filters, freshness, alerts, and validation. Use for dashboard, KPI dashboard, analytics dashboard, reporting board, or operational metrics view. Turkish triggers: dashboard yap, KPI panosu, filtre ve tazelik, karar odaklı raporlama.

# Data Dashboard

Build a dashboard as a decision interface, not a collection of charts.

1. Define audience, decisions, owner, cadence, data freshness, metric contracts, and action thresholds.
2. Limit the primary view to the few measures that change decisions; place diagnostic detail behind drill-downs.
3. Specify filters, segmentation, comparison baselines, empty/error states, and point-in-time semantics.
4. Validate each displayed measure against the source/query and show data freshness/known gaps.
5. Review usability, accessibility, and performance before publishing.

Do not silently create external dashboards, connect data sources, or send alerts. Treat threshold colors as decision cues backed by a named owner.
